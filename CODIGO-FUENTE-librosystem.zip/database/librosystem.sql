-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 34.176.231.10    Database: librosystem
-- ------------------------------------------------------
-- Server version	8.0.31-google

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `libros`
--

DROP TABLE IF EXISTS `libros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `libros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(80) DEFAULT NULL,
  `autor` varchar(50) DEFAULT NULL,
  `descripcion` text,
  `referencia_imagen` varchar(50) DEFAULT NULL,
  `fecha_publicacion` varchar(20) DEFAULT NULL,
  `categoria` varchar(40) DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `vendidos` int DEFAULT NULL,
  `precio` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libros`
--

LOCK TABLES `libros` WRITE;
/*!40000 ALTER TABLE `libros` DISABLE KEYS */;
INSERT INTO `libros` VALUES (6,'Hunger Games','Suzanne Collinsa','  Para demostrar su poder, el régimen del estado totalitario de Panem organiza cada año \"Los juegos del hambre\". En ellos, 24 jóvenes compiten el uno contra el otro en una batalla en la que solo puede haber un superviviente. La joven Katniss se ofrece voluntaria para participar en los juegos para salvar a su hermana. Junto a ella participará Peeta, un joven al que ha conocido desde la infancia y que está enamorado de ella. Sin embargo, el Capitolio quiere convertirlos en contrincantes.   ','64d24b55a887dimage_2023-08-08_110249632.png','2008-09-14','NOVELA',1,1,2500),(7,'Soy Leyenda','Richard Matheson','Robert Neville es el único superviviente de una guerra bacteriológica que ha asolado el planeta y convertido al resto de la humanidad en vampiros. Su vida se ha reducido a asesinar el máximo número posible de estos seres sanguinarios durante el día, y a soportar su asedio cada noche. Para ellos, el auténtico monstruo es este hombre que lucha por subsistir en un nuevo orden establecido.\r\n','64d2754cf1db323ca42a508237009ce81c9bcf862df0e.webp','2007-01-17','CIENCIA FICCION',1,4,5400),(8,'Orgullo y Prejucio','Jane Austen','A lo largo de una trama que discurre con gran ritmo y precisión, Jane Austen reúne una galería de personajes característicos de toda una epoca: la dama empeñada en casar a sus hijas con el mejor partido de la región, las hermanas que se debaten con sus vaivenes sentimentales, el clérigo adulador que peca de oportunista... El estudio de carácteres y el análisis de las relaciones humanas basadas en la costumbre, elementos esenciales de la narrativa de la autora, alcanzan en Orgullo y prejuicio cotas de maestría insuperable.','64d27828a21f2R.jpg','1813-01-28','NOVELA',1,2,15000),(10,'Drácula','Bram Stoker','Es una novela gótica y de terror que cuenta la historia del conde Drácula, un vampiro inmortal que busca extender su maldición no muerta desde Transilvania a Inglaterra. La novela sigue a varios personajes, incluyendo a Jonathan Harker, Mina Murray y el profesor Abraham Van Helsing, mientras luchan por detener la influencia de Drácula y salvar a sus seres queridos de sus garras vampíricas.','64de37fe9251d1577709550.webp','1897-05-26','TERROR',6,4,10500),(11,'IT','Stephen King','Es una novela de terror de Stephen King que sigue a un grupo de amigos llamados el \"Club de los Perdedores\". Ambientada en la ficticia ciudad de Derry, Maine, la historia alterna entre dos líneas temporales: los personajes como niños en la década de 1950 y como adultos en la década de 1980. Ellos se enfrentan a una entidad malévola que puede manifestarse como los peores temores de cada uno, pero principalmente adopta la forma de Pennywise, un payaso aterrador. La novela explora temas de amistad, trauma infantil y el poder del miedo.','64de383b4ad1bOIP (1).jpg','1986-09-15','TERROR',6,0,7500),(12,'Alicia en el País de las Maravillas','Lewis Carroll','Es una novela fantástica y cómica que sigue a Alicia, una niña curiosa que cae en una madriguera de conejo y entra en un mundo extraño y surrealista. En su viaje, se encuentra con personajes extravagantes y eventos ilógicos que desafían la realidad y la lógica. La novela es una sátira de la sociedad victoriana y juega con la inversión de las normas sociales y las expectativas, creando situaciones cómicas y absurdas.','64de38ac71350OIP (2).jpg','1896-03-05','COMEDIA',1,2,5550),(13,'Las Aventuras de Tom Sawyer','Mark Twain','Es una novela humorística escrita por Mark Twain. La historia sigue a Tom Sawyer, un niño travieso y aventurero que vive en una pequeña ciudad a orillas del río Misisipi. Tom se mete en todo tipo de problemas y situaciones cómicas, como escapar de sus deberes escolares, pretender ser pirata y enfrentarse a problemas de la vida cotidiana con ingenio y humor. La novela captura la infancia y la imaginación con toques de humor y picardía.','64de38e8b7489OIP (3).jpg','1876-10-05','COMEDIA',2,0,15000),(14,'Cien años de soledad','Gabriel García Márquez','Es una obra maestra del realismo mágico escrita por Gabriel García Márquez. La novela narra la historia de la familia Buendía en el pueblo ficticio de Macondo, a lo largo de varias generaciones. La obra mezcla elementos realistas con elementos mágicos y fantásticos, creando un mundo en el que lo improbable se vuelve plausible. A través de la familia Buendía, la novela explora temas universales como el amor, la soledad, la muerte y el paso del tiempo.','64de394139fa3OIP (4).jpg','1967-05-30','NOVELA',3,0,8500),(15,'El nombre de la rosa','Umberto Eco','Es una novela ambientada en una abadía benedictina en la Edad Media. El protagonista, Guillermo de Baskerville, un monje franciscano, llega a la abadía para investigar una serie de misteriosos asesinatos. La trama se desarrolla en un contexto de disputas religiosas y filosóficas, mientras Guillermo utiliza métodos de lógica y razón para resolver los crímenes. La novela explora temas como el conocimiento, la religión y el poder, mientras teje una intrincada trama de misterio y suspenso.','64de399574fcdOIP (5).jpg','1980-06-01','MISTERIO Y SUSPENSO',10,0,12200),(16,'Perdida','Gillian Flynn','Sigue la historia de Nick y Amy Dunne, un matrimonio aparentemente perfecto que se ve afectado cuando Amy desaparece en su quinto aniversario de bodas. La novela se presenta desde las perspectivas alternas de Nick y de los diarios escritos por Amy. A medida que se revelan secretos y giros inesperados, el lector se sumerge en un mundo de engaño, manipulación y traición. La novela explora los aspectos oscuros de las relaciones y cómo la percepción pública puede ser engañosa.','64de39d18ab83R.jpg','2012-12-07','MISTERIO Y SUSPENSO',3,2,13700),(17,'El Señor de Los Anillos','J.R.R. Tolkien','Es una obra maestra de la fantasía que sigue las aventuras de Frodo Bolsón y un grupo de compañeros mientras viajan a través de la Tierra Media para destruir un poderoso anillo mágico en el Monte del Destino. La trilogía de Tolkien explora temas de amistad, valentía, sacrificio y la lucha entre el bien y el mal. Con su rica creación de mundos, razas y lenguajes, esta saga ha influido profundamente en el género de la fantasía moderna.','64de3a413c375OIP (6).jpg','1954-07-31','FANTASIA',11,1,18000),(18,'Canción de Hielo y Fuego: Juego de tronos','George R.R. Martin','Es el primer libro de la serie \"Canción de Hielo y Fuego\" de George R.R. Martin. La historia se desarrolla en el continente ficticio de Westeros y sigue a varios personajes mientras luchan por el poder en un mundo lleno de intrigas políticas, batallas y magia. La serie se caracteriza por sus giros inesperados, personajes complejos y moralidades ambiguas. La lucha por el Trono de Hierro es solo el comienzo de una historia épica de traición, lealtad y supervivencia.','64de3a8833baeR (1).jpg','1996-05-02','FANTASIA',7,0,14500),(19,'Posdata: Te amo','Cecelia Ahern','Cuenta la historia de Holly Kennedy, quien queda devastada por la muerte prematura de su esposo Gerry debido a una enfermedad. Sin embargo, Holly descubre que Gerry le ha dejado una serie de cartas planeadas para después de su muerte, cada una destinada a ayudarla a superar su dolor y redescubrir su vida. A medida que Holly sigue las cartas y emprende una serie de aventuras, también aprende a encontrar su propio camino y a sanar su corazón roto. La novela explora temas de pérdida, amor y crecimiento personal.','64de3ae300d2f702b8b9f15b52119e02afb54db24ade0.jpg','2004-02-03','ROMANCE',2,0,9500),(20,'En el camino','Jack Kerouac','Es una obra icónica de la generación beat que narra los viajes y experiencias de Sal Paradise (alter ego del autor) y su amigo Dean Moriarty a lo largo de los Estados Unidos. La novela captura el espíritu de la contracultura y la búsqueda de libertad y autodescubrimiento. A través de una prosa fluida y cargada de energía, Kerouac presenta un relato de aventuras, encuentros y desafíos, reflejando la búsqueda de sentido y la exploración del mundo en constante movimiento.','64de3b2e69478OIP (7).jpg','1957-01-03','NO FICCION NARRATIVA',0,2,6700),(21,'A sangre fría','Truman Capote','Es una novela de no ficción que relata el brutal asesinato de la familia Clutter en Kansas en 1959. Capote investiga y relata los hechos, explorando los motivos y la psicología de los asesinos, así como las reacciones de la comunidad. El libro se basa en hechos reales y presenta un estilo de escritura narrativa que combina elementos de periodismo y literatura. Es un hito en el género de la novela de crimen verdadero y es conocido por su profundidad psicológica y su enfoque en la vida de las víctimas y los perpetradores.','64de3b7f7e7b19788433902672.jpg','1966-07-06','NO FICCION NARRATIVA',2,0,9500),(22,'El diario de Ana Frank','Anne Frank','Es el conmovedor relato de Anne Frank, una joven judía que se escondió con su familia durante la ocupación nazi en los Países Bajos. Anne escribió su diario mientras estuvo escondida en un anexo secreto durante dos años. El diario documenta sus pensamientos, emociones y experiencias mientras enfrenta el miedo y la opresión. Trágicamente, Anne murió en un campo de concentración, pero su diario se convirtió en un testimonio poderoso de los horrores del Holocausto y un símbolo de esperanza y humanidad en tiempos oscuros.','64de3c8f888169781532878572.jpg','1947-08-01','BIOGRAFIAS Y MEMORIAS',4,0,16000),(23,'Mi lucha VOL 1','Adolf Hitler','Es un libro autobiográfico escrito por Adolf Hitler durante su tiempo en prisión tras un fallido golpe de Estado en 1923. El libro describe su visión política y su ideología, que sentaron las bases del nazismo. Aunque la obra es considerada altamente controvertida debido a su contenido racista, xenófobo y antisemita, es un documento histórico importante para comprender la mente y las motivaciones de Hitler y su papel en la historia del siglo XX.','64de3cda3d9eaR (2).jpg','1925-05-02','BIOGRAFIAS Y MEMORIAS',2,0,21000),(24,'Piense y hágase rico','Napoleon Hill','Es uno de los libros más influyentes en el género de autoayuda y éxito personal. Napoleon Hill presenta los principios fundamentales del éxito a través de una combinación de psicología, filosofía y experiencia personal. Hill enfatiza la importancia del pensamiento positivo, la determinación, la planificación y la persistencia para lograr metas financieras y personales. A través de historias de éxito y lecciones prácticas, el libro busca inspirar a los lectores a tomar el control de su vida y alcanzar sus objetivos.','64de3d23a1f83OIP (8).jpg','1937-06-03','AUTOAYUDA Y DESARROLLO PERSONAL',2,0,17500),(25,'Los 7 hábitos de la gente altamente efectiva','Stephen R. Covey','En este libro, Stephen R. Covey presenta siete hábitos fundamentales que pueden llevar a una vida más efectiva y satisfactoria. Los hábitos se centran en aspectos como la proactividad, la claridad de objetivos, la administración del tiempo, la empatía y la colaboración. Covey combina principios de liderazgo y desarrollo personal para ayudar a los lectores a mejorar su relación consigo mismos y con los demás. El enfoque del libro es sobre la autorreflexión y la transformación personal para lograr un cambio duradero.','64de3d58370eaOIP (9).jpg','1989-09-03','AUTOAYUDA Y DESARROLLO PERSONAL',3,1,13600),(26,'Padre rico, padre pobre','Robert T. Kiyosaki','Es un libro que cambió la forma en que muchas personas ven las finanzas personales y la inversión. En él, Robert Kiyosaki comparte las lecciones financieras que aprendió de su \"padre rico\", que era el padre de su mejor amigo, contrastándolas con las creencias financieras de su \"padre pobre\", su propio padre. Kiyosaki explora conceptos como activos y pasivos, educación financiera y cómo desarrollar una mentalidad de inversión. El libro enfatiza la importancia de aprender sobre el dinero y las inversiones desde una edad temprana para lograr la independencia financiera.','64de3dba69f1cR (3).jpg','1997-05-24','NEGOCIOS Y FINANZAS',8,0,14650),(27,'El inversor inteligente','Benjamin Graham','Es un libro clásico en el mundo de las inversiones y los mercados financieros. Escrito por Benjamin Graham, quien es considerado el \"padre del análisis de valores\", el libro presenta principios y estrategias para invertir de manera segura y sensata. Graham destaca la importancia de la investigación, el análisis fundamental y la gestión de riesgos en la toma de decisiones de inversión. El libro también introduce la noción de \"señor mercado\" para ilustrar las fluctuaciones del mercado y cómo los inversores pueden beneficiarse de ellas a largo plazo.','64de3def7a6a4OIP (10).jpg','1949-11-23','NEGOCIOS Y FINANZAS',1,0,21000),(28,'Matar a un ruiseñor','Harper Lee','Es una novela que aborda temas de racismo, moralidad y justicia a través de los ojos de Scout Finch, una niña en la pequeña ciudad de Maycomb, Alabama, durante la Gran Depresión. La historia se centra en la defensa de un hombre afroamericano acusado injustamente de violación y la lucha del abogado Atticus Finch por la verdad y la justicia. La novela es un poderoso comentario sobre la sociedad y la lucha contra los prejuicios, y se ha convertido en una obra clásica de la literatura estadounidense.','64de3ec484727OIP (11).jpg','1960-11-25','LITERATURA CLASICA',3,0,15500),(29,'Crimen y castigo','Fyodor Dostoevsky',' Sigue la historia de Raskolnikov, un estudiante pobre en San Petersburgo que comete un asesinato por razones filosóficas y psicológicas. A medida que se debate entre el remordimiento y la justificación, la novela explora su lucha interna y su relación con otros personajes, incluida Sonia Marmeládov, una joven prostituta. La novela profundiza en temas de culpa, redención y moralidad, y es un estudio profundo de la psicología humana en un contexto de la Rusia del siglo XIX.','64de3efe00ad7R (4).jpg','1886-08-04','LITERATURA CLASICA',0,0,55000),(30,'Breve historia del tiempo','Stephen Hawking','En \"Breve historia del tiempo\", el renombrado físico teórico Stephen Hawking explora conceptos complejos de la cosmología, como el Big Bang, los agujeros negros y la naturaleza del tiempo. Aunque el contenido está basado en la física teórica, Hawking logra presentar los conceptos de manera accesible para el lector no especializado. El libro se ha convertido en un éxito de ventas y es conocido por su capacidad para hacer que la ciencia avanzada sea comprensible y apasionante para un público más amplio.','64de3f4f3815dOIP (12).jpg','1988-05-13','CIENCIA Y DIVULGACION CIENTIFICA',2,0,18500),(31,'Cosmos','Carl Sagan',' Es una obra influyente que explora una amplia gama de temas científicos, desde el origen del universo hasta la evolución de la vida en la Tierra y la exploración espacial. Escrito por el astrónomo Carl Sagan, el libro presenta una visión poética y filosófica de la ciencia, haciendo hincapié en la maravilla y la belleza del cosmos. A través de \"Cosmos\", Sagan busca transmitir su amor por la ciencia y estimular la curiosidad y la apreciación por el universo que habitamos. ','64de3f7c98492OIP (13).jpg','1980-11-12','CIENCIA Y DIVULGACION CIENTIFICA',2,0,15000),(32,'Sapiens: De animales a dioses','Yuval Noah Harari','Abarca la historia de la humanidad desde los primeros seres humanos hasta la era actual. El autor, Yuval Noah Harari, explora cómo los seres humanos pasaron de ser cazadores-recolectores a formar sociedades complejas y cómo se desarrollaron instituciones, religiones, economías y tecnologías. El libro examina el impacto de la revolución agrícola, la revolución industrial y la revolución científica en la evolución de la humanidad. Harari presenta una narración accesible y panorámica de la historia humana, basada en investigaciones antropológicas y científicas.','64de3fe89dc35OIP (14).jpg','2011-12-05','HISTORIA',7,1,16000),(33,'Un mundo desbocado: Los efectos de la globalización en nuestras vidas','Thomas L. Friedman',' \"Un mundo desbocado\" explora los efectos de la globalización en la sociedad contemporánea. El autor, Thomas L. Friedman, analiza cómo la tecnología, la economía y la política han interconectado al mundo de formas nunca antes vistas. Friedman utiliza la metáfora del \"Lexus\" (representando la globalización tecnológica y económica) y el \"olivo\" (representando la identidad, la cultura y la tradición) para ilustrar los desafíos y las tensiones en un mundo cada vez más interdependiente. El libro ofrece una visión de los aspectos positivos y negativos de la globalización y cómo impactan en las vidas de las personas.','64de403c2e5346ce4ac4a62c4dbd2e4f091f2894698eb.webp','1999-07-06','HISTORIA',1,0,15000),(34,'Hoja de hierba','Walt Whitman','Es una colección de poemas escrita por el poeta estadounidense Walt Whitman. Whitman explora temas como la naturaleza, la individualidad, la democracia y la conexión entre los seres humanos. Los poemas celebran la vida y la diversidad humana, y están escritos en un estilo libre y expansivo que rompió con las convenciones poéticas de la época. La obra es considerada un hito en la poesía estadounidense y ha influido en generaciones de poetas.','64de40ff0c0deOIP (15).jpg','1898-04-06','POESIA',3,0,16500),(35,'Veinte poemas de amor y una canción desesperada','Pablo Neruda','Es una colección de poemas escrita por el poeta chileno Pablo Neruda cuando tenía tan solo 19 años. Los poemas exploran el tema del amor en todas sus facetas, desde la pasión y la intimidad hasta la melancolía y la desesperación. Neruda utiliza un lenguaje apasionado y sensorial para capturar las emociones y las experiencias del amor. La colección es una de las más famosas de Neruda y ha dejado una marca duradera en la poesía amorosa.','64de4134df392OIP (16).jpg','1924-01-20','POESIA',6,0,13500),(36,'En el corazón de los bosques','Jon Krakauer','Cuenta la historia real de Christopher McCandless, un joven que abandonó su vida convencional y emprendió un viaje solitario hacia el norte de Alaska en busca de la naturaleza salvaje y la autenticidad. La historia es una exploración de la conexión entre el ser humano y la naturaleza, así como de los peligros y desafíos de aventurarse en lo desconocido. Basado en investigaciones y entrevistas, el libro es un relato fascinante y conmovedor de la búsqueda de McCandless por la libertad y la verdad.','64de41ab28f3cOIP (17).jpg','1996-09-28','VIAJES Y AVENTURAS',7,3,9800),(37,'El libro de la selva','Rudyard Kipling','Es una colección de cuentos ambientada en la selva de la India, donde los personajes principales son animales que interactúan con el protagonista humano, Mowgli. Los cuentos siguen las aventuras de Mowgli mientras se enfrenta a peligros y desafíos en compañía de personajes como Baloo el oso, Bagheera la pantera y Shere Khan el tigre. Los cuentos exploran temas de la naturaleza, la lealtad y el crecimiento personal. La obra ha sido adaptada en numerosas ocasiones y ha dejado una huella duradera en la literatura infantil y de aventuras.','64de41f1070b1R (5).jpg','1894-12-21','VIAJES Y AVENTURAS',2,0,13700);
/*!40000 ALTER TABLE `libros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `libros_vendidos`
--

DROP TABLE IF EXISTS `libros_vendidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `libros_vendidos` (
  `ventaid` int DEFAULT NULL,
  `libroid` int DEFAULT NULL,
  `titulo` varchar(50) DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  `costototal` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libros_vendidos`
--

LOCK TABLES `libros_vendidos` WRITE;
/*!40000 ALTER TABLE `libros_vendidos` DISABLE KEYS */;
INSERT INTO `libros_vendidos` VALUES (5,4,'El Hobbit',1,8516),(5,1,'El Señor de los Anillos',1,125),(5,1,'El Señor de los Anillos',1,125),(23,8,'Orgullo y Prejucio',1,15000),(25,7,'Soy Leyenda',1,5400),(26,7,'Soy Leyenda',1,5400),(26,12,'Alicia en el País de las Maravillas',2,11100),(27,17,'El Señor de Los Anillos',1,18000),(27,25,'Los 7 hábitos de la gente altamente efectiva',1,13600),(28,8,'Orgullo y Prejucio',1,15000),(28,32,'Sapiens: De animales a dioses',1,16000),(29,36,'En el corazón de los bosques',3,29400),(29,10,'Drácula',1,10500),(29,16,'Perdida',1,13700),(31,10,'Drácula',1,10500),(31,16,'Perdida',1,13700),(31,20,'En el camino',2,13400),(32,10,'Drácula',1,10500),(33,7,'Soy Leyenda',1,5400);
/*!40000 ALTER TABLE `libros_vendidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `dni` int DEFAULT NULL,
  `rol` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'luisito','123345','luis carrizo',45007207,1),(2,'momo','123','momo benavides',124124,3),(3,'jorgito123','123345','Jorge Lopez',45454545,2),(4,'manu123','manue123','Manuel Lopez',21344112,2),(5,'elgrandanes','123456','Cristian Lopez',41222331,1),(6,'pepito','pepito123','Jose Argentino',1234565,1),(7,'elpepo123','santi123','Santiago Lopez',28800621,1),(8,'franchu2020','fran2020','Francisco Glew',4155000,3);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idusuario` int DEFAULT NULL,
  `cantidadtotal` int DEFAULT NULL,
  `costototal` int DEFAULT NULL,
  `mediodepago` varchar(50) DEFAULT NULL,
  `metododeentrega` varchar(30) DEFAULT NULL,
  `direccionenvio_calle` varchar(50) DEFAULT NULL,
  `direccionenvio_altura` int DEFAULT NULL,
  `direccionenvio_localidad` varchar(50) DEFAULT NULL,
  `direccionenvio_provincia` varchar(50) DEFAULT NULL,
  `estado` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
INSERT INTO `ventas` VALUES (3,2,1,250,'Efectivo','ENVIAR','machain',123,'catan','bs as','ENVIADO'),(4,2,2,11516,'Tarjeta','ENVIAR','sunchales',123,'lafe','chaco','ENVIADO'),(7,2,1,125,'Efectivo','RETIRAR','',0,'','','ENVIADO'),(8,2,2,17532,'Efectivo','ENVIAR','pepe',13,'catan','bs as','ENVIADO'),(9,2,3,11641,'Tarjeta','RETIRAR','',0,'','','ENVIADO'),(10,2,1,375,'Tarjeta','RETIRAR','',0,'','','ENVIADO'),(11,2,1,8516,'Transferencia','RETIRAR','',0,'','','ENTREGADO'),(12,2,1,8516,'Transferencia','RETIRAR','',0,'','','ENVIADO'),(13,2,1,125,'Tarjeta','RETIRAR','',0,'','','ENVIADO'),(14,2,1,125,'Transferencia','RETIRAR','',0,'','','ENVIADO'),(15,2,2,18032,'Transferencia','RETIRAR','',0,'','','ENTREGADO'),(16,2,2,18032,'Transferencia','RETIRAR','',0,'','','ENVIADO'),(17,2,2,11016,'Transferencia','RETIRAR','',0,'','','RECHAZADO'),(18,2,2,9016,'Tarjeta','RETIRAR','',0,'','','RECHAZADO'),(19,2,1,8516,'Transferencia','RETIRAR','',0,'','','ENVIADO'),(20,2,1,1000,'Efectivo','ENVIAR','asd',154,'catan','bs as','ENTREGADO'),(21,2,1,1000,'Efectivo','ENVIAR','asd',154,'catan','bs as','ENVIADO'),(22,2,2,1100,'Efectivo','RETIRAR','',0,'','','RECHAZADO'),(23,2,1,15000,'Efectivo','RETIRAR','',0,'','','POR RETIRAR'),(24,2,1,5400,'','RETIRAR','',0,'','','ENVIADO'),(25,2,1,5400,'','RETIRAR','',0,'','','POR RETIRAR'),(26,4,2,16500,'Efectivo','RETIRAR','',0,'','','POR RETIRAR'),(27,4,2,31600,'Tarjeta','ENVIAR','Lope de Vega',2121,'laferrere','bsas','A ENVIAR'),(28,5,2,31000,'Efectivo','RETIRAR','',0,'','','POR RETIRAR'),(29,5,3,53600,'Transferencia','RETIRAR','',0,'','','POR RETIRAR'),(30,5,1,10500,'Transferencia','RETIRAR','',0,'','','ENVIADO'),(31,6,3,37600,'Tarjeta','ENVIAR','los manzanares',123,'20 de junio','bsas','A ENVIAR'),(32,8,1,10500,'Tarjeta','RETIRAR','',0,'','','POR RETIRAR'),(33,2,1,5400,'Efectivo','RETIRAR','',0,'','','POR RETIRAR');
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 18:58:51
